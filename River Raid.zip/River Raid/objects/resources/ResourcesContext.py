class ResourceContext:
    pass
