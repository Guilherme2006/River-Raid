# Space Raid
River Raid based of Space Raid implementation in Python

How to run the game:
Install python 3.4
Install pygame (pip install pygame)
Run python __init__.py

